import { db } from '../firebaseConfig';
import { doc, getDoc, runTransaction, setDoc, collection, addDoc, serverTimestamp } from 'firebase/firestore';

const counterDocRef = doc(db, 'settings', 'counterDoc');
const evraklarColRef = collection(db, 'evraklar');

export async function getCurrentCounter() {
  const snap = await getDoc(counterDocRef);
  if (!snap.exists()) return 0;
  const data = snap.data();
  return data?.currentCounter ?? 0;
}

export async function incrementCounterAtomic() {
  const newVal = await runTransaction(db, async (tx) => {
    const snap = await tx.get(counterDocRef);
    let current = 0;
    if (snap.exists()) current = snap.data()?.currentCounter ?? 0;
    const next = current + 1;
    tx.set(counterDocRef, { currentCounter: next }, { merge: true });
    return next;
  });
  return newVal;
}

export async function updateCounter(value) {
  await setDoc(counterDocRef, { currentCounter: value }, { merge: true });
}

export async function addEvrakWithBarcode(barcodeData, counter) {
  const docRef = await addDoc(evraklarColRef, {
    barcode: barcodeData,
    counter,
    createdAt: serverTimestamp(),
  });
  return docRef.id;
}